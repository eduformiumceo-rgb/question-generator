/**
 * TopicSelector
 * Curriculum + Topics step of the exam wizard. GES-only, by design.
 *
 * Flow order - CLASS FIRST, then Subject - matches the real Lesson
 * Planner's CurriculumSelector exactly, verified against src/App.jsx
 * before building this, not guessed:
 *   - ALL_CLASSES is a static, grouped list (Kindergarten / Lower Primary /
 *     Upper Primary / Junior High School / Senior High School), shown
 *     unconditionally as Step 1 - same grouping, same order as the real app.
 *   - Subject only appears once a class is chosen, and the subject list is
 *     FILTERED to that class: `SUPPORTED_SUBJECTS.filter(s =>
 *     getSupportedClasses(s).includes(className))` - the real app's exact
 *     line, not a new lookup function (curriculumIndex.js has no
 *     class-first lookup; the real app derives it client-side the same way).
 *   - Strand → Sub-Strand only appear once Subject is chosen, same
 *     progressive-disclosure pattern.
 *
 * SENIOR HIGH SCHOOL follows the Lesson Planner's two-tier flow exactly:
 *   SHS 1/2/3 -> Programme / Course (General Science, Business, General Arts,
 *   Visual Arts, Home Economics, Agricultural Science, Technical, STEM / TVET,
 *   Core Subjects) -> Subject -> Strands -> Topics. Subjects come from
 *   shsCourses.js (a copy of the planner's SHS_COURSES) and strands/sub-strands
 *   from the same getStrands/getSubStrands helpers. The subject is shown and
 *   stored by its clean name ("Biology"); the internal key ("Biology (GS)") only
 *   drives the curriculum lookup. A subject with no NaCCA data yet stays
 *   selectable and falls back to the pasted syllabus.
 *
 * Four layered ways to set scope, most-automatic first:
 *   0. UPLOAD your Scheme of Learning (Word .docx or PDF). It is read in the
 *      browser (schemeReader.js), its text fills the scheme box below, and the
 *      strands / sub-strands it mentions are matched to the NaCCA curriculum
 *      and ticked automatically (schemeMatch.js). Upload first or pick the
 *      subject first - the match re-runs whenever either changes.
 *   1. "Load my Scheme of Learning" - pulls the teacher's own saved SOL
 *      (or, failing that, aggregated weekly lesson plans) from the SAME
 *      Supabase `lesson_plans` table the Lesson Planner already writes to.
 *   2. Paste the scheme/syllabus directly - the fallback when #1 finds
 *      nothing, or for SHS (see scope note above).
 *   3. Manual multi-strand + multi-sub-strand picker - always available.
 *
 * IMPORTANT: curriculum data itself is still reused, never duplicated -
 *   import { SUPPORTED_SUBJECTS, getSupportedClasses, getStrands, getSubStrands }
 *     from "../curriculumIndex.js";
 */
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  SUPPORTED_SUBJECTS, getSupportedClasses, getStrands, getSubStrands,
} from "../curriculumIndex.js";
import { getToken } from "../auth.js";
import {
  SHS_COURSES, OTHER_SUBJECT_KEY, isSHSClass, displaySubject, shsSubjectsForCourse,
} from "../shsCourses.js";
import { readSchemeFile, SchemeReadError, SCHEME_ACCEPT } from "../schemeReader.js";
import { condenseSchemeText, matchSchemeToCurriculum } from "../schemeMatch.js";
import { MAX_SYLLABUS_CHARS, MAX_TOPICS } from "../moderation.js";

// Large scheme buttons. Flat by design (no shadows, no icons).
// "solid" = the main action (upload); "outline" = the secondary one (load saved).
const bigBtn = (F, variant, disabled) => ({
  width: "100%", height: 52, padding: "0 20px", borderRadius: 12, boxSizing: "border-box",
  display: "flex", alignItems: "center", justifyContent: "center", textAlign: "center",
  fontFamily: F, fontSize: 15, fontWeight: 800, letterSpacing: ".02em", lineHeight: 1.2,
  cursor: disabled ? "default" : "pointer", opacity: disabled ? 0.65 : 1,
  WebkitTapHighlightColor: "transparent", touchAction: "manipulation", boxShadow: "none",
  ...(variant === "solid"
    ? { background: "linear-gradient(135deg,#0D9488 0%,#0891B2 100%)", color: "#fff", border: "none" }
    : { background: "transparent", color: "var(--accent)", border: "2px solid var(--accent)" }),
});

const SOL_LOOKUP_API = "/api/exam-account/sol-lookup";

// Exact grouping and order from the real App.jsx's Step 1 class Select.
const CLASS_GROUPS = [
  { label: "Kindergarten", classes: ["KG 1", "KG 2"] },
  { label: "Lower Primary", classes: ["Basic 1", "Basic 2", "Basic 3"] },
  { label: "Upper Primary", classes: ["Basic 4", "Basic 5", "Basic 6"] },
  { label: "Junior High School", classes: ["Basic 7", "Basic 8", "Basic 9"] },
  { label: "Senior High School", classes: ["SHS 1", "SHS 2", "SHS 3"] },
];

export default function TopicSelector({
  subject, setSubject,
  className, setClassName,
  shsCourse, setShsCourse, // SHS only: programme / course
  shsKey, setShsKey,       // SHS only: internal curriculum key, e.g. "Biology (GS)"
  term, // read-only here - used only to scope the SOL lookup
  selectedTopics, setSelectedTopics,
  pastedSyllabus, setPastedSyllabus,
  onSuggestTopics,
  onLoginRequired, // called instead of hitting the server when signed out
  S, F,
}) {
  const [selectedStrands, setSelectedStrands] = useState([]); // string[]
  const [suggesting, setSuggesting] = useState(false);
  const [solStatus, setSolStatus] = useState(null); // { loading, source, savedAt, weeksFound, error }

  // Uploaded scheme file: { name, kind, pages, text (full), inserted (what went into the box), truncated, originalLength }
  const [scheme, setScheme] = useState(null);
  const [schemeBusy, setSchemeBusy] = useState(false);
  const [schemeError, setSchemeError] = useState("");
  const [schemeMatch, setSchemeMatch] = useState(null); // { strands, topics, total } once matched against the curriculum
  const [dragging, setDragging] = useState(false);
  const fileInputRef = useRef(null);
  const schemeMatchRef = useRef(null); // latest match, readable from async handlers without stale closures

  const isSHS = isSHSClass(className);
  const shsOther = isSHS && shsKey === OTHER_SUBJECT_KEY;

  // The key that drives the curriculum lookup: the planner-style internal key
  // for SHS ("Biology (GS)"), the plain subject name for Basic classes.
  const lookupKey = isSHS ? (shsOther ? "" : shsKey || "") : subject;

  // Same derivation as the real App.jsx: subjects available for the chosen
  // class, not classes available for a chosen subject.
  const availableSubjects = useMemo(() => {
    if (!className || isSHS) return [];
    return SUPPORTED_SUBJECTS.filter(s => getSupportedClasses(s).includes(className));
  }, [className, isSHS]);

  const shsSubjects = useMemo(() => (isSHS && shsCourse ? shsSubjectsForCourse(shsCourse) : []), [isSHS, shsCourse]);
  const shsPicked = shsSubjects.find(s => s.key === shsKey) || null;

  // Reset downstream selections when the class changes - a stale subject/strand
  // pick from a different class would silently mis-scope the exam. Moving
  // between SHS 1/2/3 keeps the programme and subject (the teacher is still
  // setting a paper for the same course) but clears strands, which differ by year.
  const prevClass = useRef(className);
  useEffect(() => {
    const stayingInSHS = isSHSClass(prevClass.current) && isSHSClass(className);
    prevClass.current = className;
    if (!stayingInSHS) { setSubject(""); setShsCourse?.(""); setShsKey?.(""); }
    setSelectedStrands([]); setSelectedTopics([]); setSolStatus(null);
  }, [className]); // eslint-disable-line
  useEffect(() => { setSelectedStrands([]); setSelectedTopics([]); }, [lookupKey]); // eslint-disable-line

  const pickCourse = (course) => {
    setShsCourse(course); setShsKey(""); setSubject("");
    setSelectedStrands([]); setSelectedTopics([]); setSolStatus(null);
  };
  const pickShsSubject = (key) => {
    setShsKey(key);
    setSubject(key === OTHER_SUBJECT_KEY || !key ? "" : displaySubject(key));
    setSelectedStrands([]); setSelectedTopics([]); setSolStatus(null);
  };

  const strands = useMemo(() => (lookupKey && className ? getStrands(lookupKey, className) : []), [lookupKey, className]);
  const subStrandsByStrand = useMemo(() => {
    const map = {};
    selectedStrands.forEach(strandName => {
      map[strandName] = getSubStrands(lookupKey, className, strandName).map(ss => ss.name);
    });
    return map;
  }, [lookupKey, className, selectedStrands]);

  // Match the uploaded scheme to the curriculum. Runs when a scheme arrives AND whenever the
  // class/subject changes (the reset effects above have just cleared the ticks, so this re-applies
  // them) - which is what lets a teacher upload first and pick the subject afterwards.
  useEffect(() => {
    if (!scheme || !lookupKey || !className || !strands.length) { schemeMatchRef.current = null; setSchemeMatch(null); return; }
    const m = matchSchemeToCurriculum(scheme.text, strands, subject);
    const topics = m.topics.slice(0, MAX_TOPICS); // the server rejects more than MAX_TOPICS
    setSelectedStrands(prev => Array.from(new Set([...prev, ...m.strands])));
    setSelectedTopics(prev => Array.from(new Set([...prev, ...topics])));
    schemeMatchRef.current = { strands: m.strands, topics, total: m.topics.length };
    setSchemeMatch(schemeMatchRef.current);
  }, [scheme, lookupKey, className, subject]); // eslint-disable-line

  const handleSchemeFile = useCallback(async (file) => {
    if (!file) return;
    setSchemeBusy(true); setSchemeError("");
    try {
      const { text, kind, pages, pagesSkipped } = await readSchemeFile(file);
      const c = condenseSchemeText(text, MAX_SYLLABUS_CHARS);
      // Replacing a scheme: take back what the OLD one ticked, so its topics don't leak into this exam.
      const old = schemeMatchRef.current;
      if (old) {
        setSelectedTopics(prev => prev.filter(t => !old.topics.includes(t)));
        setSelectedStrands(prev => prev.filter(st => !old.strands.includes(st)));
      }
      setScheme({ name: file.name, kind, pages, pagesSkipped, text, inserted: c.text, truncated: c.truncated, originalLength: c.originalLength });
      setPastedSyllabus(c.text);
    } catch (e) {
      setSchemeError(e instanceof SchemeReadError ? e.message : "Couldn't read that file. Please try another one, or paste the text below.");
    } finally {
      setSchemeBusy(false);
    }
  }, [setPastedSyllabus, setSelectedTopics]);

  const removeScheme = () => {
    if (schemeMatch) {
      // undo what this upload ticked, so "Remove" really removes its influence
      setSelectedTopics(prev => prev.filter(t => !schemeMatch.topics.includes(t)));
      setSelectedStrands(prev => prev.filter(st => !schemeMatch.strands.includes(st)));
    }
    if (scheme && pastedSyllabus === scheme.inserted) setPastedSyllabus(""); // keep it if the teacher has edited it
    schemeMatchRef.current = null;
    setScheme(null); setSchemeMatch(null); setSchemeError("");
  };

  const toggleStrand = (strandName) => {
    setSelectedStrands(prev => prev.includes(strandName) ? prev.filter(s => s !== strandName) : [...prev, strandName]);
  };
  const toggleTopic = (t) => {
    setSelectedTopics(prev => prev.includes(t) ? prev.filter(x => x !== t) : [...prev, t]);
  };

  const handleSuggest = async () => {
    if (!onSuggestTopics) return;
    setSuggesting(true);
    try {
      const suggested = await onSuggestTopics(subject, className, selectedStrands[0] || "", isSHS ? shsCourse : "");
      setSelectedTopics(prev => Array.from(new Set([...prev, ...suggested])));
    } finally {
      setSuggesting(false);
    }
  };

  const loadScheme = async () => {
    if (!subject || !className) return;
    if (!getToken || !getToken()) { onLoginRequired?.(); return; }
    setSolStatus({ loading: true });
    try {
      const token = getToken();
      const params = new URLSearchParams({ subject, className, ...(term ? { term } : {}) });
      const res = await fetch(`${SOL_LOOKUP_API}?${params}`, { headers: { Authorization: `Bearer ${token}` } });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Couldn't load your Scheme of Learning.");

      if (data.source === "none" || !data.strands?.length) {
        setSolStatus({ loading: false, source: "none" });
        return;
      }
      const matchedStrandNames = data.strands.map(s => s.strand).filter(name => strands.some(st => st.strand === name));
      setSelectedStrands(prev => Array.from(new Set([...prev, ...matchedStrandNames])));
      const allSubStrands = data.strands.flatMap(s => s.subStrands);
      setSelectedTopics(prev => Array.from(new Set([...prev, ...allSubStrands])));
      setSolStatus({ loading: false, source: data.source, savedAt: data.savedAt, weeksFound: data.weeksFound, term: data.term, matchedCount: matchedStrandNames.length, totalCount: data.strands.length });
    } catch (e) {
      setSolStatus({ loading: false, error: e.message || "Couldn't load your Scheme of Learning." });
    }
  };

  return (
    <div style={S.card}>
      <h3 style={{ margin: "0 0 4px", fontSize: 16, fontWeight: 700, color: "var(--text)", fontFamily: F }}>
        Curriculum <span style={{ fontSize: 11.5, fontWeight: 600, color: "var(--text-muted)" }}>(GES / NaCCA)</span>
      </h3>
      <p style={{ margin: "0 0 16px", fontSize: 12.5, color: "var(--text-muted)", fontFamily: F, lineHeight: 1.5 }}>
        Choose the class first. The subject list is filtered to what's actually taught at that level.
      </p>

      {/* -- STEP 1: Class - always shown first -- */}
      <div style={{ marginBottom: className ? 20 : 0 }}>
        <label style={S.lbl}>Class *</label>
        <select value={className} onChange={e => setClassName(e.target.value)} style={S.sel}>
          <option value="">- Select Class -</option>
          {CLASS_GROUPS.map(group => (
            <optgroup key={group.label} label={group.label}>
              {group.classes.map(c => <option key={c} value={c}>{c}</option>)}
            </optgroup>
          ))}
        </select>
      </div>

      {/* -- STEP 2: Subject - shown only once a class is chosen, filtered to that class -- */}
      {className && !isSHS && (
        <div style={{ marginBottom: subject ? 20 : 0 }}>
          <label style={S.lbl}>Subject *</label>
          <select value={subject} onChange={e => setSubject(e.target.value)} style={S.sel}>
            <option value="">- Select Subject -</option>
            {availableSubjects.map(sub => <option key={sub} value={sub}>{sub}</option>)}
          </select>
        </div>
      )}

      {/* -- SHS STEP 2: Programme / Course -- */}
      {isSHS && (
        <div style={{ marginBottom: shsCourse ? 20 : 0 }}>
          <label style={S.lbl}>Programme / Course *</label>
          <select value={shsCourse || ""} onChange={e => pickCourse(e.target.value)} style={S.sel}>
            <option value="">- Select Programme -</option>
            {Object.keys(SHS_COURSES).map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
      )}

      {/* -- SHS STEP 3: Subject, filtered to the programme -- */}
      {isSHS && shsCourse && (
        <div style={{ marginBottom: shsKey ? 20 : 0 }}>
          <label style={S.lbl}>Subject *</label>
          <select value={shsKey || ""} onChange={e => pickShsSubject(e.target.value)} style={S.sel}>
            <option value="">- Select Subject -</option>
            {shsSubjects.map(s => (
              <option key={s.key} value={s.key}>{s.label}{s.hasCurriculum ? "" : " (paste syllabus)"}</option>
            ))}
            <option value={OTHER_SUBJECT_KEY}>Other subject (type it in)</option>
          </select>
        </div>
      )}

      {shsOther && (
        <div style={{ marginBottom: 12 }}>
          <label style={S.lbl}>Subject name *</label>
          <input value={subject} onChange={e => setSubject(e.target.value)} placeholder="e.g. Elective Geography" style={S.inp} />
        </div>
      )}

      {isSHS && (shsOther || (shsPicked && !shsPicked.hasCurriculum)) && (
        <div style={{ fontSize: 12, color: "var(--text-muted)", fontFamily: F, lineHeight: 1.5, background: "var(--accent-soft)", border: "1px solid var(--tag-border)", borderRadius: 10, padding: "10px 12px", marginBottom: 4 }}>
          {shsOther ? "" : `NaCCA strands for ${shsPicked.label} aren't loaded yet. `}
          Paste your syllabus or topic list below and the paper will be built from it.
        </div>
      )}

      {/* -- UPLOAD: Word / PDF scheme, read in the browser -- */}
      {className && (
        <div style={{ marginTop: 20 }}>
          <label style={S.lbl}>Start with your Scheme of Learning</label>
          <input
            ref={fileInputRef} type="file" accept={SCHEME_ACCEPT} style={{ display: "none" }}
            aria-label="Upload scheme of learning file"
            onChange={e => { const f = e.target.files?.[0]; e.target.value = ""; handleSchemeFile(f); }}
          />
          {!scheme && (
            <div
              onDragOver={e => { e.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={e => { e.preventDefault(); setDragging(false); if (!schemeBusy) handleSchemeFile(e.dataTransfer.files?.[0]); }}
            >
              <button
                type="button" aria-busy={schemeBusy} disabled={schemeBusy}
                onClick={() => fileInputRef.current?.click()}
                style={{
                  ...bigBtn(F, "solid", schemeBusy),
                  ...(dragging ? { background: "var(--accent-hover)" } : null),
                }}
              >
                {schemeBusy ? "Reading your scheme…" : "Upload My Scheme of Learning"}
              </button>
              <div style={{ fontSize: 12, color: "var(--text-muted)", fontFamily: F, marginTop: 8, lineHeight: 1.5 }}>
                Word (.docx) or PDF, up to 10 MB. The app reads it and picks out your topics for you, so there is no need to type anything. You can also drop the file onto this button.
              </div>
            </div>
          )}

          {scheme && (
            <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap", border: "1.5px solid var(--tag-border)", background: "var(--accent-soft)", borderRadius: 12, padding: "10px 14px", fontFamily: F }}>
              <div style={{ flex: "1 1 180px", minWidth: 0 }}>
                <div style={{ fontSize: 13.5, fontWeight: 700, color: "var(--accent)", overflowWrap: "anywhere" }}>{scheme.name}</div>
                <div style={{ fontSize: 11.5, color: "var(--text-muted)", marginTop: 2 }}>
                  {scheme.originalLength.toLocaleString()} characters read{scheme.pages ? ` from ${scheme.pages} page${scheme.pages === 1 ? "" : "s"}` : ""}
                </div>
              </div>
              <button type="button" style={S.sm} disabled={schemeBusy} onClick={() => fileInputRef.current?.click()}>{schemeBusy ? "Reading…" : "Replace"}</button>
              <button type="button" style={S.danger} disabled={schemeBusy} onClick={removeScheme}>Remove</button>
            </div>
          )}

          <div aria-live="polite">
            {schemeError && <div style={{ ...S.err, marginTop: 10, marginBottom: 0 }}><span>{schemeError}</span></div>}

            {scheme && !schemeError && (
              <div style={{ fontSize: 12.5, color: "var(--text-muted)", fontFamily: F, lineHeight: 1.5, marginTop: 8 }}>
                {schemeMatch?.topics.length > 0 ? (
                  <>
                    <b style={{ color: "var(--accent)" }}>Found {schemeMatch.topics.length} topic{schemeMatch.topics.length === 1 ? "" : "s"}</b> in {schemeMatch.strands.length} strand{schemeMatch.strands.length === 1 ? "" : "s"} and ticked {schemeMatch.topics.length === 1 ? "it" : "them"} below. Review the selection, then adjust anything before generating.
                    {schemeMatch.total > schemeMatch.topics.length && ` Only the first ${MAX_TOPICS} of ${schemeMatch.total} were ticked (the most one paper can use).`}
                  </>
                ) : !subject && !(isSHS && shsOther) ? (
                  "Scheme read. Now choose your subject and its topics will be ticked for you."
                ) : strands.length ? (
                  "Scheme read, but no curriculum topics could be matched automatically. Tick them below. Your scheme text will still be used to build the paper."
                ) : (
                  "Scheme read. Its text will be used to build the paper."
                )}
              </div>
            )}
            {scheme?.truncated && (
              <div style={{ ...S.err, marginTop: 10, marginBottom: 0 }}>
                <span>
                  Your scheme is long, so only the first {scheme.inserted.length.toLocaleString()} of {scheme.originalLength.toLocaleString()} characters
                  are used for the paper. Edit the text below to keep just the weeks you're examining.
                </span>
              </div>
            )}
            {scheme?.pagesSkipped && (
              <div style={{ ...S.err, marginTop: 10, marginBottom: 0 }}><span>Only the first 80 pages of that PDF were read.</span></div>
            )}
          </div>
        </div>
      )}

      {subject && className && (!isSHS || !shsOther) && (
        <div style={{ marginTop: 16, marginBottom: 4 }}>
          <button type="button" onClick={loadScheme} disabled={solStatus?.loading} style={bigBtn(F, "outline", solStatus?.loading)}>
            {solStatus?.loading ? "Checking your Scheme of Learning…" : "Load My Scheme of Learning"}
          </button>
          <div style={{ fontSize: 12, color: "var(--text-muted)", fontFamily: F, marginTop: 8, lineHeight: 1.5 }}>
            Loads the Scheme of Learning you already created and saved in the Lesson Planner, so you do not have to upload it again.
          </div>

          {solStatus && !solStatus.loading && solStatus.source === "scheme_of_learning" && (
            <div style={{ ...S.err, background: "var(--accent-soft)", borderColor: "var(--tag-border)", color: "var(--accent)", marginTop: 10, marginBottom: 0 }}>
              <span>
                Loaded {solStatus.matchedCount} strand(s) from your saved Scheme of Learning
                {solStatus.term ? ` (${solStatus.term})` : ""}. Review the selection below. Add or remove anything before generating.
              </span>
            </div>
          )}
          {solStatus && !solStatus.loading && solStatus.source === "weekly_plans_partial" && (
            <div style={{ ...S.err, marginTop: 10, marginBottom: 0 }}>
              <span>
                No saved Scheme of Learning found. Loaded strands from {solStatus.weeksFound} saved weekly lesson plan(s)
                instead. This may not cover the whole term. Please double-check the selection below.
              </span>
            </div>
          )}
          {solStatus && !solStatus.loading && solStatus.source === "none" && (
            <div style={{ fontSize: 12, color: "var(--text-muted)", fontFamily: F, marginTop: 8 }}>
              No saved Scheme of Learning found. Select strands manually below, or list your topics.
            </div>
          )}
          {solStatus?.error && (
            <div style={{ ...S.err, marginTop: 10, marginBottom: 0 }}><span>{solStatus.error}</span></div>
          )}
        </div>
      )}

      {className && strands.length > 0 && (
        <div style={{ marginTop: 20, marginBottom: 4 }}>
          <label style={S.lbl}>Strands taught this {isSHS ? "semester" : "term"} (select any number)</label>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
            {strands.map(st => {
              const active = selectedStrands.includes(st.strand);
              return (
                <button key={st.strand} type="button" onClick={() => toggleStrand(st.strand)} style={{
                  padding: "8px 14px", borderRadius: 99, fontFamily: F, fontSize: 12.5, fontWeight: 600, cursor: "pointer",
                  border: `1.5px solid ${active ? "var(--accent)" : "var(--border-strong)"}`,
                  background: active ? "var(--accent-soft)" : "var(--card-bg)",
                  color: active ? "var(--accent)" : "var(--text-secondary)",
                }}>
                  {st.strand}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {selectedStrands.length > 0 && (
        <div style={{ marginTop: 16 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
            <label style={{ ...S.lbl, marginBottom: 0 }}>Topics (Sub-Strands)</label>
            {onSuggestTopics && (
              <button type="button" onClick={handleSuggest} disabled={suggesting} style={{ ...S.sm, height: 30, fontSize: 11.5, opacity: suggesting ? 0.6 : 1 }}>
                {suggesting ? "Suggesting…" : "AI Suggest Topics"}
              </button>
            )}
          </div>
          {selectedStrands.map(strandName => (
            <div key={strandName} style={{ marginBottom: 10 }}>
              <div style={{ fontSize: 11.5, fontWeight: 700, color: "var(--text-muted)", fontFamily: F, marginBottom: 4 }}>{strandName}</div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                {(subStrandsByStrand[strandName] || []).map(name => {
                  const active = selectedTopics.includes(name);
                  return (
                    <button key={name} type="button" onClick={() => toggleTopic(name)} style={{
                      padding: "7px 14px", borderRadius: 99, fontFamily: F, fontSize: 12.5, fontWeight: 500,
                      cursor: "pointer", WebkitTapHighlightColor: "transparent",
                      border: `1.5px solid ${active ? "var(--accent)" : "var(--border-strong)"}`,
                      background: active ? "var(--accent-soft)" : "var(--card-bg)",
                      color: active ? "var(--accent)" : "var(--text-secondary)",
                    }}>
                      {name}
                    </button>
                  );
                })}
                {!(subStrandsByStrand[strandName] || []).length && (
                  <span style={{ fontSize: 12, color: "var(--text-muted)", fontFamily: F }}>No sub-strands found.</span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {className && (
        <div style={{ marginTop: 20 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", gap: 8 }}>
            <label style={S.lbl}>{scheme ? "Scheme text (edit to focus the paper on certain weeks)" : "Or list topics (optional)"}</label>
            {pastedSyllabus.length > MAX_SYLLABUS_CHARS * 0.8 && (
              <span style={{ fontSize: 11.5, fontFamily: F, fontWeight: 600, flexShrink: 0, marginBottom: 7, color: pastedSyllabus.length > MAX_SYLLABUS_CHARS ? "var(--err-text)" : "var(--text-muted)" }}>
                {pastedSyllabus.length.toLocaleString()} / {MAX_SYLLABUS_CHARS.toLocaleString()}
              </span>
            )}
          </div>
          <textarea
            value={pastedSyllabus}
            onChange={e => setPastedSyllabus(e.target.value)}
            placeholder="List the topics to be examined, separated by commas or one per line…"
            rows={scheme ? 8 : 3}
            style={{ ...S.inp, minHeight: 76, resize: "vertical", fontFamily: F, lineHeight: 1.5 }}
          />
        </div>
      )}

      {className && !selectedTopics.length && !pastedSyllabus.trim() && (
        <div style={{ ...S.err, marginTop: 14, marginBottom: 0 }}>
          <span>Select at least one topic, upload your scheme, or paste a syllabus, before generating.</span>
        </div>
      )}
    </div>
  );
}
